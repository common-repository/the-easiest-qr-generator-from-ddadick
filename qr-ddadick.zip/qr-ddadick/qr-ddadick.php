<?php

/*
Plugin Name: The easiest QR generator from dDadick
Plugin URI: http://ddadick.prodadi.info/?p=135&lang=en
Description: To use the paste in the HTML-code tag &lt;qrddadickimgtooltip&gt;TEXT&lt;/qrddadickimgtooltip&gt; or &lt;qrddadickimgtooltip tooltip=&quot;ToolTipText&quot;;&gt;TEXT&lt;/qrddadickimgtooltip&gt;. In the syntax of the tag &lt;qrddadickimgtooltip tooltip=&quot;ToolTipText&quot;;&gt;TEXT&lt;/qrddadickimgtooltip&gt; use of the mark ";" after end of any parameter of the tag is mandatory. The presence of the mark &quot; (the quotation marks) is mandatory.
Author: dDadick
Version: 1.0
Author URI: http://ddadick.prodadi.info/?lang=en

    The easiest QR generator from dDadick
    Copyright (C) 2010-2011  Gubenko Denis Pavlovich

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.


    In creating this code is used such software:
    1) QRcode image PHP scripts version 0.50i (C)2000-2009,Y.Swetake (http://www.swetake.com/)
    2) jQuery Tooltip plugin 1.3 (http://bassistance.de/jquery-plugins/jquery-plugin-tooltip/
       and http://docs.jquery.com/Plugins/Tooltip).

    The license "QRcode image PHP scripts version 0.50i" is England is contained in the file
    /qr-ddadick/qr/php/README-e.txt , namely (item 5, Notice):
      "THIS SOFTWARE IS PROVIDED BY Y.Swetake ``AS IS'' AND ANY EXPRESS OR
      IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
      OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
      IN NO EVENT SHALL Y.Swetake OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
      INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
      (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
      LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)  HOWEVER CAUSED 
      AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
      OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
      USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE."

    jQuery Tooltip plugin 1.3 is available immediately for two licenses - the MIT and GPL:
      - http://www.opensource.org/licenses/mit-license.php
      - http://www.gnu.org/licenses/gpl.html

    Author plugin "The easiest QR generator from dDadick" thanks developers
    "QRcode image PHP scripts version 0.50i" and "jQuery Tooltip plugin 1.3"
    for the opportunity to use the code "QRcode image PHP scripts version 0.50i"
    and code "jQuery Tooltip plugin 1.3" that is expressed in the licenses
    "QRcode image PHP scripts version 0.50i" and "jQuery Tooltip plugin 1.3", in the draft.
*/
$qrddadickimgtooltip_call=0;
$qrddadickimgtooltip_d=array();
$qrddadickimgtooltip_txt=array();
function ddadick_init_javascript($matches) {
echo '
<link rel="stylesheet" href="'.WP_PLUGIN_URL.'/qr-ddadick/jquery-tooltip/jquery.tooltip.css" />
<link rel="stylesheet" href="'.WP_PLUGIN_URL.'/qr-ddadick/jquery-tooltip/screen.css" />
<script type="text/javascript" src="'.WP_PLUGIN_URL.'/qr-ddadick/jquery-tooltip/lib/jquery.js"></script>
<script type="text/javascript" src="'.WP_PLUGIN_URL.'/qr-ddadick/jquery-tooltip/lib/jquery.bgiframe.js"></script>
<script type="text/javascript" src="'.WP_PLUGIN_URL.'/qr-ddadick/jquery-tooltip/lib/jquery.dimensions.js"></script>
<script type="text/javascript" src="'.WP_PLUGIN_URL.'/qr-ddadick/jquery-tooltip/jquery.tooltip.js"></script>';
}

function qrddadickimgtooltip_start($matches) {
global $qrddadickimgtooltip_call;
global $qrddadickimgtooltip_d;
global $qrddadickimgtooltip_txt;
$qrddadickimgtooltip_call=$qrddadickimgtooltip_call+1;
$qrddadickimgtooltip_d[$qrddadickimgtooltip_call]=$matches[0];
$qrddadickimgtooltip_txt[$qrddadickimgtooltip_call]=$matches[0];
$qrddadickimgtooltip_start_regs = split(';', $matches[1]);
for ($i_qrddadick=1; $i_qrddadick<=count($qrddadickimgtooltip_start_regs); $i_qrddadick++) {
  preg_match('|(.*?)="(.*?)"|i', $qrddadickimgtooltip_start_regs[$i_qrddadick-1], $qrddadickimgtooltip_start_regsi);
  if (trim($qrddadickimgtooltip_start_regsi[1])=='tooltip') {
    $qrddadickimgtooltip_d[$qrddadickimgtooltip_call]=$qrddadickimgtooltip_start_regsi[2];
  }
}
return '<span id="qrddadickimgtooltip'.$qrddadickimgtooltip_call.'">'.preg_replace("|(</qrddadickimgtooltip>)|i", "", $matches[0]).'</span>';
}
 
function ddadick_generate_qr($content) {

global $qrddadickimgtooltip_call;
global $qrddadickimgtooltip_d;
global $qrddadickimgtooltip_txt;

// qrddadickimgtooltip --START
/*
    - Used variables qrddadickimgtooltip_call, qrddadickimgtooltip_d, qrddadickimgtooltip_txt.
    - For application use tags <qrddadickimgtooltip>...</qrddadickimgtooltip>.
    - If you use tags <qrddadickimgtooltip>TEXT</qrddadickimgtooltip> without any parameters,
      then as a tooltip will appear QR-code the selected TEXT between
      the tags <qrddadickimgtooltip>TEXT</qrddadickimgtooltip>.
    - If you use tags <qrddadickimgtooltip tooltip="TOOLTIP";>TEXT</qrddadickimgtooltip>
      with parameters, as a tooltip will appear QR-code parameter 'tooltip' tag
      <qrddadickimgtooltip tooltip="TOOLTIP";>TEXT</qrddadickimgtooltip>.
    - Picture QR-code parameter 'tooltip' tag <qrddadickimgtooltip tooltip="TOOLTIP";>TEXT</qrddadickimgtooltip>
      in the tooltip that appears to be signed value TEXT.
    - In the syntax of the tag <qrddadickimgtooltip tooltip="TOOLTIP";>TEXT</qrddadickimgtooltip>
      use of the mark ";" after end of any parameter of the tag is mandatory.
    - The presence of the mark " (the quotation marks) is mandatory.
*/
$content=preg_replace_callback("|<qrddadickimgtooltip(.*?)>(.*?)<\/qrddadickimgtooltip>|i", qrddadickimgtooltip_start, $content);
$content=preg_replace("|(<qrddadickimgtooltip(.*?)>)|i", "", $content);
for ($i_qrddadick=1; $i_qrddadick<=$qrddadickimgtooltip_call; $i_qrddadick++){
$qrddadickimgtooltip_d[$i_qrddadick]=preg_replace ("|</qrddadickimgtooltip>|i", "",$qrddadickimgtooltip_d[$i_qrddadick]);
$qrddadickimgtooltip_d[$i_qrddadick]=preg_replace ("|<qrddadickimgtooltip(.*?)>|i", "",$qrddadickimgtooltip_d[$i_qrddadick]);
$qrddadickimgtooltip_txt[$i_qrddadick]=preg_replace ("|</qrddadickimgtooltip>|i", "",$qrddadickimgtooltip_txt[$i_qrddadick]);
$qrddadickimgtooltip_txt[$i_qrddadick]=preg_replace ("|<qrddadickimgtooltip(.*?)>|i", "",$qrddadickimgtooltip_txt[$i_qrddadick]);
$content_javascript='$(\'#qrddadickimgtooltip'.$i_qrddadick.'\').tooltip({track:true,delay:0,showBody:" - ",bodyHandler:function(){return $("<center><img src=\''.WP_PLUGIN_URL.'/qr-ddadick/qr/php/qr_img.php?d='.rawurlencode($qrddadickimgtooltip_d[$i_qrddadick]).'&e=H&s=8&t=J\' height=\'400\' /></br><p>'.$qrddadickimgtooltip_txt[$i_qrddadick].'</p><center>");}});
'.$content_javascript;
}
if ($content_javascript){
$content='<script type="text/javascript">$(function(){
'.$content_javascript.'});
</script>
'.$content;
}
// qrddadickimgtooltip --END

return $content;

}
add_action('wp_head', 'ddadick_init_javascript');
add_filter('the_content', 'ddadick_generate_qr');
?>